#!/bin/bash
y=5