#!/bin/bash
x=5