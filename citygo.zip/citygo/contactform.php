<?php
$username = "root";
$password = "";
$hostname = "localhost";
$database = "citygo";
$con = mysqli_connect($hostname,$username,$password,$database) or die;
 if(isset($_POST['submit']))
 {
  echo "kjkhkjhkhkj";
 }
 else
 {
  echo "khj";
 }

?>